from Utils.data_loader import load_data
from Utils.data_manipulation import (
    keep_buy_sell,
    filter_dates,
    total_transactions,
    top3_symbols,
    top5_sectors,
    top5_industries
)
from Utils.charts import (
    clean_spines,
    count_axis,
    integer_axis,
    annotate_hbar,
    format_date_axis,
    highlight_max_point
)

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt


st.set_page_config(
    page_title="Time Analysis",
    layout="wide"
)

df = load_data()

st.title("Time Analysis")
st.write("This page shows how BUY and SELL transactions change over time.")

# Date filters
filter_row = st.container()

with filter_row:
    col_start, col_end = st.columns(2)

    start_date = col_start.date_input(
        "Start date",
        value=pd.to_datetime("2024-01-01")
    )

    end_date = col_end.date_input(
        "End date",
        value=pd.to_datetime("2024-12-31")
    )

if start_date > end_date:
    st.error("The start date cannot be after the end date.")

else:
    start = pd.to_datetime(start_date)
    end = pd.to_datetime(end_date)

    df_trading = keep_buy_sell(df)
    df_filtered = filter_dates(df_trading, start, end)

    st.divider()

    # KPI row
    kpi1, kpi2, kpi3 = st.columns(3)

    kpi1.metric(
        "BUY and SELL transactions",
        len(df_filtered)
    )

    kpi2.metric(
        "Traded symbols",
        df_filtered["symbol"].nunique()
    )

    kpi3.metric(
        "Active sectors",
        df_filtered["sector"].nunique()
    )

    st.divider()

    # Main dashboard area
    left_col, right_col = st.columns([2, 1])

    with left_col:
        st.subheader("BUY and SELL transactions over time")

        time_series = total_transactions(start, end, df)

        fig1, ax1 = plt.subplots(figsize=(8, 3.5))
        ax1.plot(
            time_series.index,
            time_series.values,
            marker="o" if len(time_series) <= 14 else None
        )
        highlight_max_point(ax1, time_series)

        ax1.set_xlabel("Date")
        ax1.set_ylabel("Transactions")

        clean_spines(ax1)
        count_axis(ax1, max_value=time_series.max(), axis="y")
        format_date_axis(ax1, start, end)

        ax1.grid(axis="y", alpha=0.15)
        plt.xticks(rotation=30)
        plt.tight_layout()

        st.pyplot(fig1)

    with right_col:
        st.subheader("Top 3 symbols")

        df_top3 = top3_symbols(start, end, df)

        fig2, ax2 = plt.subplots(figsize=(4, 3.5))
        ax2.barh(df_top3.index, df_top3["n_transactions"])
        ax2.set_xlabel("Transactions")
        ax2.set_ylabel("Symbol")

        clean_spines(ax2)
        integer_axis(ax2, axis="x")
        annotate_hbar(ax2)

        ax2.grid(axis="x", alpha=0.15)
        plt.tight_layout()

        st.pyplot(fig2)

    st.divider()

    bottom_left, bottom_right = st.columns(2)

    with bottom_left:
        st.subheader("Top 5 sectors")

        df_top5_sector = top5_sectors(start, end, df)

        fig3, ax3 = plt.subplots(figsize=(6, 3.5))
        ax3.barh(df_top5_sector.index, df_top5_sector["n_transactions"])
        ax3.set_xlabel("Transactions")
        ax3.set_ylabel("Sector")

        clean_spines(ax3)
        integer_axis(ax3, axis="x")
        annotate_hbar(ax3)

        ax3.grid(axis="x", alpha=0.15)
        plt.tight_layout()

        st.pyplot(fig3)

    with bottom_right:
        st.subheader("Top 5 industries")

        df_top5_industry = top5_industries(start, end, df)

        fig4, ax4 = plt.subplots(figsize=(6, 3.5))
        ax4.barh(df_top5_industry.index, df_top5_industry["n_transactions"])
        ax4.set_xlabel("Transactions")
        ax4.set_ylabel("Industry")

        clean_spines(ax4)
        integer_axis(ax4, axis="x")
        annotate_hbar(ax4)

        ax4.grid(axis="x", alpha=0.15)
        plt.tight_layout()

        st.pyplot(fig4)