import pandas as pd
import matplotlib.dates as mdates
from matplotlib.ticker import MaxNLocator


def clean_spines(ax):
    """Remove unnecessary chart borders."""
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.set_axisbelow(True)
    return ax


def integer_axis(ax, axis="y"):
    """Force axis ticks to show integer values."""
    if axis == "x":
        ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    else:
        ax.yaxis.set_major_locator(MaxNLocator(integer=True))

    return ax


def count_axis(ax, max_value, axis="y"):
    """Set a count axis starting from zero and using integer ticks."""
    upper = max(1, int(max_value))
    upper = upper + max(1, int(upper * 0.15))

    if axis == "x":
        ax.set_xlim(0, upper)
        ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    else:
        ax.set_ylim(0, upper)
        ax.yaxis.set_major_locator(MaxNLocator(integer=True))

    return ax


def annotate_hbar(ax):
    """Add integer labels to horizontal bars."""
    max_width = max([patch.get_width() for patch in ax.patches], default=0)

    if max_width > 0:
        ax.set_xlim(0, max_width * 1.15)

    for patch in ax.patches:
        width = patch.get_width()
        y = patch.get_y() + patch.get_height() / 2

        ax.text(
            width,
            y,
            f"  {int(width)}",
            va="center",
            fontsize=9
        )

    return ax


def format_date_axis(ax, start, end):
    """Format date axis without showing hours."""
    start = pd.to_datetime(start)
    end = pd.to_datetime(end)

    n_days = (end - start).days

    if n_days == 0:
        ax.set_xlim(
            start - pd.Timedelta(days=0.5),
            end + pd.Timedelta(days=0.5)
        )
        ax.xaxis.set_major_locator(mdates.DayLocator(interval=1))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))

    elif n_days <= 14:
        ax.set_xlim(start, end)
        ax.xaxis.set_major_locator(mdates.DayLocator(interval=1))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))

    elif n_days <= 90:
        ax.set_xlim(start, end)
        ax.xaxis.set_major_locator(mdates.WeekdayLocator(interval=1))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))

    else:
        ax.set_xlim(start, end)
        ax.xaxis.set_major_locator(mdates.MonthLocator(interval=1))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%b"))

    return ax

def highlight_max_point(ax, series):
    """Highlight the maximum value in a time series."""
    if len(series) == 0:
        return ax

    max_date = series.idxmax()
    max_value = series.max()

    ax.scatter(max_date, max_value, zorder=3)

    ax.annotate(
        f"Max: {int(max_value)}",
        xy=(max_date, max_value),
        xytext=(0, 8),
        textcoords="offset points",
        ha="center",
        fontsize=9
    )

    return ax