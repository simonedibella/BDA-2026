from Utils.data_loader import load_data, load_geography
from Utils.data_manipulation import (
    keep_buy_sell,
    filter_country,
    country_transactions,
    top_industries_by_type
)
from Utils.charts import (
    clean_spines,
    count_axis,
    integer_axis,
    annotate_hbar,
    format_date_axis,
    highlight_max_point
)

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt


st.set_page_config(
    page_title="Country Analysis",
    layout="wide"
)

df = load_data()
geography = load_geography()

df_trading = keep_buy_sell(df)

st.title("Country Analysis")
st.write(
    "This page focuses on the country associated with the traded stock."
)

country_list = sorted(geography["country"].dropna().unique())

selected_country = st.selectbox(
    "Select country",
    country_list
)

country_df = filter_country(selected_country, df_trading)

st.divider()

if len(country_df) == 0:
    st.warning("No transactions available for the selected country.")

else:
    buy_count = len(country_df[country_df["transaction_type"] == "BUY"])
    sell_count = len(country_df[country_df["transaction_type"] == "SELL"])

    # KPI row
    kpi1, kpi2, kpi3 = st.columns(3)

    kpi1.metric(
        "BUY and SELL transactions",
        len(country_df)
    )

    kpi2.metric(
        "BUY transactions",
        buy_count
    )

    kpi3.metric(
        "SELL transactions",
        sell_count
    )

    st.divider()

    # Main country trend
    st.subheader(f"BUY and SELL transactions in {selected_country} during 2024")

    country_series = country_transactions(selected_country, df)

    fig1, ax1 = plt.subplots(figsize=(12, 3.5))
    ax1.plot(
        country_series.index,
        country_series.values
    )
    highlight_max_point(ax1, country_series)

    ax1.set_xlabel("Date")
    ax1.set_ylabel("Transactions")

    clean_spines(ax1)
    count_axis(ax1, max_value=country_series.max(), axis="y")
    format_date_axis(
        ax1,
        start=pd.to_datetime("2024-01-01"),
        end=pd.to_datetime("2024-12-31")
    )

    ax1.grid(axis="y", alpha=0.15)
    plt.xticks(rotation=30)
    plt.tight_layout()

    st.pyplot(fig1)

    st.divider()

    # BUY and SELL industry charts
    col_buy, col_sell = st.columns(2)

    with col_buy:
        st.subheader("Top industries by BUY")

        df_buy = top_industries_by_type(selected_country, "BUY", df)

        if len(df_buy) == 0:
            st.info("No BUY transactions for this country.")
        else:
            fig2, ax2 = plt.subplots(figsize=(6, 3.5))
            ax2.barh(df_buy.index, df_buy["n_transactions"])
            ax2.set_xlabel("BUY transactions")
            ax2.set_ylabel("")

            clean_spines(ax2)
            integer_axis(ax2, axis="x")
            annotate_hbar(ax2)

            ax2.grid(axis="x", alpha=0.15)
            ax2.tick_params(axis="y", labelsize=9)
            plt.tight_layout()

            st.pyplot(fig2)

    with col_sell:
        st.subheader("Top industries by SELL")

        df_sell = top_industries_by_type(selected_country, "SELL", df)

        if len(df_sell) == 0:
            st.info("No SELL transactions for this country.")
        else:
            fig3, ax3 = plt.subplots(figsize=(6, 3.5))
            ax3.barh(df_sell.index, df_sell["n_transactions"])
            ax3.set_xlabel("SELL transactions")
            ax3.set_ylabel("")

            clean_spines(ax3)
            integer_axis(ax3, axis="x")
            annotate_hbar(ax3)

            ax3.grid(axis="x", alpha=0.15)
            ax3.tick_params(axis="y", labelsize=9)
            plt.tight_layout()

            st.pyplot(fig3)