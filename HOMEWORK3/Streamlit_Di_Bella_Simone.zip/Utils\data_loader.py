from pathlib import Path

import pandas as pd
import streamlit as st


@st.cache_data
def load_data():
    try:
        file_path = Path(__file__).resolve().parents[1] / "Data" / "analytical_view.csv"

        df = pd.read_csv(file_path)
        df["date"] = pd.to_datetime(df["date"])

        return df

    except Exception as error:
        st.error(f"Could not load the data: {error}")
        st.stop()


@st.cache_data
def load_geography():
    try:
        file_path = Path(__file__).resolve().parents[1] / "Data" / "dim_geography.csv"

        geography = pd.read_csv(file_path)

        return geography

    except Exception as error:
        st.error(f"Could not load the geography data: {error}")
        st.stop()