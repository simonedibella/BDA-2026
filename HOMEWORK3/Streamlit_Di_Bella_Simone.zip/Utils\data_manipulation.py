import pandas as pd


def keep_buy_sell(df):
    df = df[df["transaction_type"].isin(["BUY", "SELL"])].copy()
    return df


def filter_dates(df, start, end):
    start = pd.to_datetime(start)
    end = pd.to_datetime(end)

    df = df[
        (df["date"] >= start) &
        (df["date"] <= end)
    ].copy()

    return df


def total_transactions(start, end, df):
    df_t = keep_buy_sell(df)
    df_t = filter_dates(df_t, start, end)

    df_t["day"] = df_t["date"].dt.normalize()

    df_t = df_t.groupby("day").agg(
        n_transactions=("transaction_type", "count")
    )

    days = pd.date_range(start=start, end=end, freq="D")
    result = df_t["n_transactions"].reindex(days, fill_value=0)

    return result


def top3_symbols(start, end, df):
    df_top = keep_buy_sell(df)
    df_top = filter_dates(df_top, start, end)

    result = df_top.groupby("symbol").agg(
        n_transactions=("transaction_type", "count")
    )

    result = result.nlargest(3, "n_transactions")
    result = result.sort_values("n_transactions", ascending=True)

    return result


def top5_sectors(start, end, df):
    df_top = keep_buy_sell(df)
    df_top = filter_dates(df_top, start, end)

    result = df_top.groupby("sector").agg(
        n_transactions=("transaction_type", "count")
    )

    result = result.nlargest(5, "n_transactions")
    result = result.sort_values("n_transactions", ascending=True)

    return result


def top5_industries(start, end, df):
    df_top = keep_buy_sell(df)
    df_top = filter_dates(df_top, start, end)

    result = df_top.groupby("industry").agg(
        n_transactions=("transaction_type", "count")
    )

    result = result.nlargest(5, "n_transactions")
    result = result.sort_values("n_transactions", ascending=True)

    return result


def filter_country(country, df):
    df_country = df[df["country"] == country].copy()
    return df_country


def country_transactions(country, df):
    df_c = keep_buy_sell(df)
    df_c = filter_country(country, df_c)

    df_c["day"] = df_c["date"].dt.normalize()

    df_c = df_c.groupby("day").agg(
        n_transactions=("transaction_type", "count")
    )

    days = pd.date_range(
        start=pd.to_datetime("2024-01-01"),
        end=pd.to_datetime("2024-12-31"),
        freq="D"
    )

    result = df_c["n_transactions"].reindex(days, fill_value=0)

    return result


def top_industries_by_type(country, transaction_type, df):
    df_c = filter_country(country, df)

    df_c = df_c[df_c["transaction_type"] == transaction_type].copy()

    result = df_c.groupby("industry").agg(
        n_transactions=("transaction_type", "count")
    )

    result = result.nlargest(5, "n_transactions")
    result = result.sort_values("n_transactions", ascending=True)

    return result