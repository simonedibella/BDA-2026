import streamlit as st

from Utils.data_loader import load_data
from Utils.data_manipulation import keep_buy_sell


st.set_page_config(
    page_title="Financial Transactions Dashboard",
    layout="wide"
)

st.title("Financial Transactions Dashboard")

st.write(
    "This dashboard analyzes financial transactions from the 2024 account statement. "
    "It focuses on BUY and SELL transactions and allows the user to explore the data "
    "by time and by country."
)

df = load_data()
df_trading = keep_buy_sell(df)

st.divider()

# KPI row
col1, col2, col3, col4 = st.columns(4)

col1.metric(
    "BUY and SELL transactions",
    len(df_trading)
)

col2.metric(
    "Traded symbols",
    df_trading["symbol"].nunique()
)

col3.metric(
    "Countries with transactions",
    df_trading["country"].nunique()
)

col4.metric(
    "Sectors",
    df_trading["sector"].nunique()
)

st.divider()

# Main pages
st.subheader("Dashboard sections")

page1, page2 = st.columns(2)

with page1:
    with st.container(border=True):
        st.markdown("### Time Analysis")
        st.write(
            "This page shows how BUY and SELL transactions change over time. "
            "The user can choose a date range and inspect the main temporal patterns."
        )

        st.markdown(
            """
            It includes:
            - daily transaction trend;
            - top 3 traded symbols;
            - top 5 sectors;
            - top 5 industries.
            """
        )

with page2:
    with st.container(border=True):
        st.markdown("### Country Analysis")
        st.write(
            "This page focuses on the country associated with the traded stock. "
            "The user can select a country and compare BUY and SELL activity."
        )

        st.markdown(
            """
            It includes:
            - country selector;
            - country-level transaction trend;
            - top industries by BUY;
            - top industries by SELL.
            """
        )

st.divider()

# Project notes
note1, note2 = st.columns(2)

with note1:
    with st.container(border=True):
        st.markdown("### Analytical scope")
        st.write(
            "The dashboard focuses only on BUY and SELL transactions. "
            "Dividend-related records are not included in the visual analysis."
        )

with note2:
    with st.container(border=True):
        st.markdown("### Data model")
        st.write(
            "The app uses the analytical view exported from the star schema. "
            "This view combines the transaction fact table with time, symbol, geography "
            "and transaction type dimensions."
        )

st.info(
    "Use the sidebar to open the Time Analysis page or the Country Analysis page."
)